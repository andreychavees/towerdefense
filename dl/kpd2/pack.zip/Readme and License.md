# 📜 CC0 1.0 Universal (Public Domain Dedication)  

**You are free to:**  
- Use this asset in personal and commercial projects.  
- Modify, distribute, and perform the asset, even for commercial purposes, without asking for permission.  

**You are not required to:**  
- Give credit to the original creator.  
- Share your modified versions under the same license.  

**🚫 No Warranties:**  
This asset is provided **"as-is"** without any warranties, express or implied. The creator is not responsible for any damages resulting from its use.  

---

❤️ If you like this asset, consider supporting me or checking out my other work:  
- [My site](https://murlyka.com)
- [Behance](https://www.behance.net/murlyka)  
- [Itch](https://akylrum.itch.io/)  
- [Gumroad](https://akylrum.gumroad.com/)  

Feel free to write me an email: to.murlyka@gmail.com

Thank you for using this asset! I hope it helps you create something amazing.  

For more information, see the full [CC0 1.0 Universal License](https://creativecommons.org/publicdomain/zero/1.0/).  